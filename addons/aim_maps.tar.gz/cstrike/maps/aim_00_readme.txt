aim_00! (aim_00.bsp)
==================================

Aim-Multiplayer map for Half-Life Counterstrike
-------------------------------------------------------

General
-------
Author			: Gimli
E-Mail			: GimliW@gmx.net

Textures		: Diggedagge, Blazeer

Sky			: the cstrike team
Sound Editing		: -
Models                  : -

Map Information
---------------
Version			: Final Version 1.0 (28/03/2006)
Spawn Points		: 32
Other Notes		: Just aim!


Construction
------------
Level Editor		: Valve Hammer Editor Beta 3.5
Compile Tools		: Zoner's HL Tools 1.7p15 modified by XP-Cagey
Compile Time		: ~0,2 h on an AMD64 3700+, 1024 MB RAM
Build Time		: ~4 hours but many more testing :-)


Other Maps from same author
---------------------------
de_alps
cs_alps
csde_gimlirats
he_nature
de_esl_autumn

latest news: http://www.gimli-maps.de


Install Information
-------------------
Unzip all files into your Half-Life / Counter-Strike directory



Notes
-----

You may only distribute this map via internet or BBS. 
You are not allowed to distribute this map or parts of
the zip-file containing the map on a CD.



Credits
-------
Greetings to the guys from #cs.maps (quakenet) and #clan00,
especially to Doc, Mewel, Jayjay, Sumi and the rest of the cs squad.
Thx to the mentioned artists for making awesome textures, skies, sounds and models.

Big thx to NicTheSick / quiqueg for intensive beta testing.


Copyright
---------
�2006 by Daniel "Gimli" Westhofen 