This Folder contains the translated Versions of
Botchat.txt. To use one of them copy it from this folder into
the main Podbot Folder, rename the "botchat.txt" to something
and rename the copied one to the original name of "botchat.txt".

NOTE:
By now these translated versions (except for the german translation)
don't use the advanced functions of the chat. Look at the english
chat to see all of the replacement markers. 